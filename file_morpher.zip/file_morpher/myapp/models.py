from django.db import models

# Create your models here.

def user_image_path(instance,filename):
    return f"uploads/{instance.folder_name}/{filename}"
class UploadedImage(models.Model):
    image = models.ImageField(upload_to=user_image_path)
    folder_name = models.CharField(max_length=255)