# myapp/views.py
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.views import APIView
from .models import UploadedImage
from django.http import HttpResponse
from reportlab.pdfgen import canvas
from PIL import Image
from reportlab.lib.pagesizes import A4
import uuid

def aspect(img):
    width, height = A4
    aspect_ratio = img.width / img.height
    new_width = min(img.width, width - 50)
    new_height = int(new_width / aspect_ratio)
    if new_height > height:
        new_height = height - 50
        new_width = int(new_height * aspect_ratio)
    return new_width, new_height
class GeneratePdf(APIView):
    parser_classes = (MultiPartParser, FormParser)


    def post(self, request, *args, **kwargs):
        # Retrieve the image from the request
        folder_name = uuid.uuid4()
        images = request.FILES.getlist('image')
        print(images)
        for image in images:
            obj = UploadedImage(image = image,folder_name=folder_name)
            obj.save()

        # Generate PDF
        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="output.pdf"'

        img_paths=[img.image.path for img in UploadedImage.objects.filter(folder_name=folder_name)]
        pdf = canvas.Canvas(response, pagesize=A4)
        for img_path in img_paths:
            img = Image.open(img_path)
            width, height = aspect(img)
            pdf.drawInlineImage(img_path, (A4[0] - width) / 2, (A4[1] - height) / 2, width=width, height=height)
            pdf.showPage()
        pdf.save()

        return response



