from django.urls import path
from .views import GeneratePdf

urlpatterns = [
    path('generate-pdf/',GeneratePdf.as_view(),name='generate_pdf')
]