from rest_framework import serializers
from .models import UploadedImage

class UploadedImageSerializers(serializers.ModelSerializer):
    class Meta:
        model = UploadedImage
        fields = ['image','folder_name']


